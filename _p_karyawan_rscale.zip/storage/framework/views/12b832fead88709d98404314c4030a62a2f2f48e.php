<div class="col-3">
    <ul class="nav nav-pills flex-column">
    <?php if(Auth::user()->role_id === 1): ?> 
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">Dashboard</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('role.index')); ?>">Jabatan</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('user.index')); ?>">Pegawai</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('variable.index')); ?>">Variable</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('indikator.index')); ?>">Indikator</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('penilaian.index')); ?>">Penilaian</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('penilaian.daily')); ?>">Laporan</a>
      </li>
    <?php endif; ?>
    <?php if(Auth::user()->role_id === 2): ?> 
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('user.index')); ?>">Pegawai</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('penilaian.index')); ?>">Penilaian</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('penilaian.daily')); ?>">Laporan</a>
      </li>
    <?php endif; ?>
    <?php if(Auth::user()->role_id === 3): ?> 
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('penilaian.daily')); ?>">Laporan</a>
      </li>
    <?php endif; ?>
    </ul>
</div><?php /**PATH D:\WEBDEV\laragon\www\_p_karyawan_rscale\resources\views/backend/pages/_partials/sidebar.blade.php ENDPATH**/ ?>