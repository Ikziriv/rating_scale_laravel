<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <?php echo $__env->make('backend.pages._partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="col-9">
                            <div class="row">
                                <div class="col-12">
                                  <div class="clearfix">
                                      <div class="float-left">
                                          Menu <br> Tambah Penilaian
                                      </div>
                                      <div class="float-right">
                                          <a href="<?php echo e(route('penilaian.index')); ?>">Kembali</a>
                                      </div>
                                  </div><hr>
                                  <div class="row">
                                      <div class="col-12">
                                        <div class="card">
                                          <div class="card-body">
                                            <form method="POST" action="<?php echo e(route('penilaian.store')); ?>">
                                              <?php echo csrf_field(); ?>
                                                <div class="form-group row">
                                                  <div class="col-sm-12">
                                                    <label for="inputEmail4">Nama Pegawai</label>
                                                    <select id="inputState" name="user_id" class="form-control form-control-sm">
                                                      <option selected disabled>Pilihan</option>
                                                      <?php $__empty_1 = true; $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                      <option value="<?php echo e($u->id); ?>"><?php echo e($u->username); ?></option>
                                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                      <option>...</option>
                                                      <?php endif; ?>
                                                    </select>
                                                  </div>
                                                </div>
                                              <?php $__empty_1 = true; $__currentLoopData = $indikators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <div class="form-group row">
                                                  <div class="col-sm-8">
                                                      <label for="staticEmail" class="col-form-label"><?php echo e($v->name); ?></label>
                                                      <input type="hidden" name="bobot_<?php echo e($v->id); ?>" value="<?php echo e($v->bobot); ?>" readonly>
                                                      <input type="hidden" name="banding_<?php echo e($v->id); ?>" value="<?php echo e($v->nilai); ?>" readonly>
                                                  </div>
                                                  <div class="col-sm-4">
                                                      <input type="number" class="form-control form-control-sm" name="nilai_<?php echo e($v->id); ?>" placeholder="Nilai Input" required>
                                                  </div>
                                                </div>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                Empty
                                              <?php endif; ?>
                                              <hr class="pt-3">
                                              <button type="submit" class="btn btn-sm btn-block btn-primary">Submit</button>
                                            </form>
                                          </div>
                                        </div>
                                      </div>
                                  </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEBDEV\laragon\www\_p_karyawan_rscale\resources\views/backend/pages/penilaian/create.blade.php ENDPATH**/ ?>