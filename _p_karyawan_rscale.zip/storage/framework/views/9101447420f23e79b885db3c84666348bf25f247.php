<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <?php echo $__env->make('backend.pages._partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="col-9">
                            <div class="row">
                                <div class="col-12">
                                    <div class="clearfix">
                                        <div class="float-left">
                                            Menu <br> Lihat Role
                                        </div>
                                        <div class="float-right">
                                            <a href="<?php echo e(route('role.index')); ?>">Kembali</a>
                                        </div>
                                    </div>
                                    </p>
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="card">
                                              <div class="card-body">
                                                <p class="card-text"><b><h5><?php echo e($role->name); ?></h5></b></p>
                                              </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEBDEV\laragon\www\_p_karyawan_rscale\resources\views/backend/pages/role/show.blade.php ENDPATH**/ ?>