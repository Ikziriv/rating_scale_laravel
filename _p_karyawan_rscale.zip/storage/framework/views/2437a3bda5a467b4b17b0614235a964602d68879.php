<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <?php echo $__env->make('backend.pages._partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="col-9">
                            <div class="row">
                                <div class="col-12">
                                  <div class="clearfix">
                                      <div class="float-left">
                                          Menu <br> Indikator
                                      </div>
                                      <div class="float-right">
                                          <a href="<?php echo e(route('home')); ?>">Kembali</a>
                                      </div>
                                  </div><hr>
                                  <div class="row">
                                      <div class="col-12">
                                          <div class="clearfix pb-3">
                                            <div class="float-left">
                                              <a class="btn btn-primary" href="<?php echo e(route('indikator.create')); ?>">Tambah Data</a>
                                            </div>
                                          </div>
                                          <table class="table table-hover">
                                            <thead>
                                              <tr>
                                                <th scope="col">#</th>
                                                <th scope="col">Variable</th>
                                                <th scope="col">Name</th>
                                                <th scope="col">Bobot</th>
                                                <th scope="col">Nilai</th>
                                                <th scope="col"></th>
                                              </tr>
                                            </thead>
                                            <tbody>
                                              <?php $__empty_1 = true; $__currentLoopData = $indikators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                              <tr>
                                                <th scope="row"><?php echo e($key+1); ?></th>
                                                <td><span class="badge badge-secondary"><?php echo e($v->variable->name); ?></span></td>
                                                <td><?php echo e($v->name); ?></td>
                                                <td><?php echo e($v->bobot); ?></td>
                                                <td><?php echo e($v->nilai); ?></td>
                                                <td class="text-right">
                                                  <div class="btn-group" role="group" aria-label="Basic example">
                                                    <a href="<?php echo e(route('indikator.show', $v->id)); ?>" class="btn btn-primary">Lihat</a>
                                                    <a class="btn btn-primary" href="<?php echo e(route('indikator.edit', $v->id)); ?>">Ubah</a>
                                                    <form id="delete-form-<?php echo e($v->id); ?>" 
                                                        method="post" 
                                                        action="<?php echo e(route('indikator.destroy', $v->id)); ?>"
                                                        style="display: none;">
                                                      <?php echo e(csrf_field()); ?>

                                                      <?php echo e(method_field('DELETE')); ?>

                                                    </form>
                                                    <a href="" class="btn btn-primary" onclick="
                                                        if(confirm('Are You Sure?')) {
                                                          event.preventDefault();
                                                          document.getElementById('delete-form-<?php echo e($v->id); ?>').submit();
                                                        } else {
                                                          event.preventDefault();
                                                        }
                                                      ">Hapus</a>
                                                  </div>
                                                </td>
                                              </tr>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                              <tr>
                                                <td>Empty</td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                              </tr>
                                              <?php endif; ?>
                                            </tbody>
                                          </table>
                                      </div>
                                  </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEBDEV\laragon\www\_p_karyawan_rscale\resources\views/backend/pages/indikator/index.blade.php ENDPATH**/ ?>