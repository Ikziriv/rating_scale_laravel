<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <?php echo $__env->make('backend.pages._partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="col-9">
                            <div class="row">
                                <div class="col-12">
                                  <div class="clearfix">
                                      <div class="float-left">
                                          Menu <br> Tambah Indikator
                                      </div>
                                      <div class="float-right">
                                          <a href="<?php echo e(route('indikator.index')); ?>">Kembali</a>
                                      </div>
                                  </div><hr>
                                  <div class="row">
                                      <div class="col-12">
                                        <div class="card">
                                          <div class="card-body">
                                            <form method="POST" action="<?php echo e(route('indikator.update', [$indikator->id])); ?>">
                                              <?php echo csrf_field(); ?>
                                              <?php echo method_field('PUT'); ?>
                                              <div class="form-group">
                                                <label for="exampleInputEmail1">Nama</label>
                                                <input type="text" class="form-control" name="name" value="<?php echo e(old('name', isset($indikator) ? $indikator->name : '')); ?>">
                                              </div>
                                              <div class="form-group">
                                                <label for="exampleInputEmail1">Nilai</label>
                                                <input type="text" class="form-control" name="nilai" value="<?php echo e(old('nilai', isset($indikator) ? $indikator->nilai : '')); ?>">
                                              </div>
                                              <hr class="pt-3">
                                              <button type="submit" class="btn btn-sm btn-block btn-primary">Submit</button>
                                            </form>
                                          </div>
                                        </div>
                                      </div>
                                  </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEBDEV\laragon\www\_p_karyawan_rscale\resources\views/backend/pages/indikator/edit.blade.php ENDPATH**/ ?>