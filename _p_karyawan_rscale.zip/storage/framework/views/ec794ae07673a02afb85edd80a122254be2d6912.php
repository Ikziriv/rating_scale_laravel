<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <?php echo $__env->make('backend.pages._partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="col-9">
                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                            <small class="float-right">You are logged in!</small>
                            <div class="row">
                                <div class="col-4">
                                    <div class="card border-primary mb-3" style="max-width: 20rem;">
                                      
                                      <div class="card-body">
                                        <h5 class="card-title">Pegawai</h5>
                                        <hr>
                                        <h3 class="card-text text-right"><?php echo e($pegawai); ?></h3>
                                      </div>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="card border-primary mb-3" style="max-width: 20rem;">
                                      
                                      <div class="card-body">
                                        <h5 class="card-title">Indikator</h5>
                                        <hr>
                                        <h3 class="card-text text-right"><?php echo e($indikator); ?></h3>
                                      </div>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="card border-primary mb-3" style="max-width: 20rem;">
                                      
                                      <div class="card-body">
                                        <h5 class="card-title">Penilaian</h5>
                                        <hr>
                                        <h3 class="card-text text-right"><?php echo e($penilaian); ?></h3>
                                      </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEBDEV\laragon\www\_p_karyawan_rscale\resources\views/home.blade.php ENDPATH**/ ?>