<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <?php echo $__env->make('backend.pages._partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="col-9">
                        <?php $dt = Carbon\Carbon::parse($date); ?>

                        <form method="GET" action="<?php echo e(route('penilaian.daily')); ?>" accept-charset="UTF-8" class="form-inline mt-3">
                            <table>
                                <tr>
                                    <td align="left"><label for="month" class="control-label text-left">Lihat Harian </label></td>
                                    <td align="right">
                                        <select class="form-control form-control-sm" id="user_id" name="user_id">
                                        <option selected disabled>Pilihan</option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($u->id); ?>"><?php echo e($u->username); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <input required="true" class="form-control form-control-sm dp" style="width:100px" name="date" type="text" value="<?php echo e($date); ?>" id="date">
                                        <div class="btn-group" role="group" aria-label="Basic example">
                                            <input class="btn btn-info btn-sm" type="submit" value="Lihat Laporan">
                                            <a href="<?php echo e(route('penilaian.daily')); ?>" class="btn btn-default btn-sm">Hari Ini</a>
                                            <a href="<?php echo e(route('penilaian.monthly', ['month' => monthNumber($dt->month), 'year' => $dt->year])); ?>" class="btn btn-default btn-sm">Lihat Bulanan</a>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                        </form>

                        <div class="card card-default table-responsive">
                            <table class="table-sm table datatable">
                                <thead>
                                    <th class="text-center">#</th>
                                    <th class="text-center">Nama</th>
                                    <th class="text-center">Tanggal</th>
                                    <th class="text-center">Skala</th>
                                    <th class="text-center">Penilaian</th>
                                    <th class="text-center">Aksi</th>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $penilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="text-center"><?php echo e(1 + $key); ?></td>
                                        <?php
                                        $pegawai = App\Pegawai::where('user_id', $v->user_id)->first();
                                        ?>
                                        <td class="text-center"><?php echo e($pegawai->name); ?></td>
                                        <td class="text-center"><?php echo e(dateId($v->created_at->format('Y-m-d'))); ?></td>
                                        <td class="text-center"><?php echo e($v->skala); ?></td>
                                        <td class="text-center"><?php echo e(number_format($v->nilai, 2)); ?> %</td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('user.show', [$v->user_id])); ?>" title="Lihat detail " target="_blank" class="btn btn-info btn-xs">Lihat Detail</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="4">Data tidak ditemukan</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
    $(function()
    {
        $(".dp").datepicker({
            dateFormat : "yy-mm-dd",
            showAnim : "fold"
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEBDEV\laragon\www\_p_karyawan_rscale\resources\views/backend/pages/penilaian/reports/daily.blade.php ENDPATH**/ ?>